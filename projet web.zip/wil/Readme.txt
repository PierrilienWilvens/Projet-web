                          
                            Universite INUKA
              
Nom              Prenom        Niveau d'etude                      Vacation
PIEERILIEN       Wilvens       2eme annee sc informatique          Median